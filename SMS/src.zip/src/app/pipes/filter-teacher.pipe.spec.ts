import { FilterTeacherPipe } from './filter-teacher.pipe';

describe('FilterTeacherPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTeacherPipe();
    expect(pipe).toBeTruthy();
  });
});
