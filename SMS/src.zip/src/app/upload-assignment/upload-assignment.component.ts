import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-upload-assignment',
  templateUrl: './upload-assignment.component.html',
  styleUrls: ['./upload-assignment.component.css']
})
export class UploadAssignmentComponent implements OnInit {
datas
prop:string
assignment

  constructor(private ds:DataService) { }

  ngOnInit(): void {
    this.ds.getstudents()
    .subscribe((d)=>{
    this.datas = d.resultData;
      console.log(this.datas)
    
  })
  }
  getAssignment(e){
    this.assignment = e.target.files[0];
  }
  postData(){
   var form = new FormData();
   form.set('assignment',this.assignment);
   form.set("StdId",this.ds.getstudents().subscribe((d)=>{this.datas = d.resultData.id}));
   this.ds.postDataWithImage(form)
   .subscribe((d)=>{
    alert(JSON.stringify(d))
   })
 }
}
